Hey, if you're reading this that means you want to add some addon to this api..

so the rules are simple, you can create a folder whatever name and you dont need
to write anything to fxmanifest.lua only what rule you need to follow is to create
two folder "client","server" so in final form it will look like this

"addon/YOUR NAME/client/whatevername.lua"<br>
"addon/YOUR NAME/server/whatevername.lua"

Please do not change anything inside of the API like the crewPhone did..<br>
it just isnt really nice way to handle API and not even planning to update it to<br>
newest version so it wont bug to the other... Yes people complaning to me that<br>
xsound is bugged when they're using like half year old version.. :)<br>
Thats why i created this addon folder so you can add your own "needed" things into it.<br>